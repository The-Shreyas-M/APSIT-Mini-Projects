from django import forms
from .models import Event

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ['title', 'venue', 'time', 'custom_fields']
        widgets = {
            'custom_fields': forms.Textarea(attrs={'rows': 3}),
        }