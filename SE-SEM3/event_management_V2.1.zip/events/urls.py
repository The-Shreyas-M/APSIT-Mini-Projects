from django.urls import path
from .views import create_event, event_list, dashboard, manage_events

urlpatterns = [
    path('create/', create_event, name='create_event'),
    path('list/', event_list, name='event_list'),
    path('dashboard/', dashboard, name='dashboard'),
    path('manage/', manage_events, name='manage_events'),
]

from .views import edit_event, delete_event

urlpatterns += [
    path('edit/<int:event_id>/', edit_event, name='edit_event'),
    path('delete/<int:event_id>/', delete_event, name='delete_event'),
]
