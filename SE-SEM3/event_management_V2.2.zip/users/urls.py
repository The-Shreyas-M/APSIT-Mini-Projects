from django.urls import path
from .views import user_login
from .views import landing_page

urlpatterns = [
    path('login/', user_login, name='login'),
    path('', landing_page, name='landing_page'),  # This will be the root URL for this app
]